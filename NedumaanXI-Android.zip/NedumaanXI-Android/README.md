# Nedumaan XI for Android

Nedumaan versus the Eleven, packaged as a full-screen Android game. It runs offline, asks for no
permissions, and keeps its save data (kasu, medals, colours, leaderboard) on the phone.

## Get the APK (no Android Studio needed)

1. Create a new repository on github.com (private is fine).
2. Upload everything in this folder to it. In the repository choose **Add file > Upload files**
   and drag the contents in. Make sure the hidden `.github` folder came along.
   If it did not, choose **Add file > Create new file**, type `.github/workflows/build-apk.yml`
   as the name, and paste in the contents of `build-apk.yml.txt`.
3. Open the **Actions** tab. The **Build APK** run starts by itself (about 5 minutes).
   If it does not, open **Build APK** and press **Run workflow**.
4. When the run turns green, open it and download **nedumaan-xi-apk** from the Artifacts list.
   Unzip it to get `app-debug.apk`.
5. Copy `app-debug.apk` to the phone and open it. Android will ask you to allow installs from
   that app (Files, Chrome, and so on). Allow it once, then install.

## Or build it yourself

Open this folder in Android Studio (Koala or newer) and choose **Build > Build APK(s)**.
From a terminal with JDK 17 and the Android SDK installed: `./gradlew assembleDebug`.
The APK lands in `app/build/outputs/apk/debug/`.

## Notes

- The APK is signed with the standard debug key. It installs and plays normally, but it is not set
  up for the Play Store. A Play Store build needs your own release signing key.
- Landscape only, Android 8.0 or newer.
- The game itself lives in `app/src/main/assets/game/index.html`. Edit it and rebuild to change the game.
- The leaderboard is stored on the device. Uninstalling the app erases it.
